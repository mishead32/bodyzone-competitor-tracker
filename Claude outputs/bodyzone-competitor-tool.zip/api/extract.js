// Vercel serverless function: keeps the Firecrawl API key on the server (never in the browser).
const SCHEMA = {
  type: "object",
  properties: {
    gym_name: { type: "string" },
    address: { type: "string" },
    phone: { type: "string" },
    timings: { type: "string" },
    joining_fee: { type: "string" },
    personal_training_price: { type: "string" },
    offers: { type: "string" },
    facilities: { type: "array", items: { type: "string" } },
    plans: {
      type: "array",
      items: {
        type: "object",
        properties: {
          plan_name: { type: "string" },
          duration: { type: "string" },
          price: { type: "string" },
        },
      },
    },
    notes: { type: "string" },
  },
};

const PROMPT =
  "This is a gym / fitness centre website. Extract: gym name, full address, phone number, " +
  "opening timings, joining/admission fee, personal training price, current offers or discounts, " +
  "list of facilities, and every membership plan with its name, duration and price (keep the currency symbol). " +
  "Only use what is written on the page. If something is not on the page, leave it empty. Do not guess.";

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Use POST" });
  }

  const apiKey = process.env.FIRECRAWL_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "FIRECRAWL_API_KEY is not set on the server" });
  }

  const body = typeof req.body === "string" ? safeParse(req.body) : req.body || {};
  const { url, password } = body;

  const appPassword = process.env.APP_PASSWORD;
  if (appPassword && password !== appPassword) {
    return res.status(401).json({ error: "Wrong password" });
  }

  let parsed;
  try {
    parsed = new URL(url);
  } catch (e) {
    return res.status(400).json({ error: "Invalid URL" });
  }
  if (!["http:", "https:"].includes(parsed.protocol)) {
    return res.status(400).json({ error: "Only http/https URLs allowed" });
  }

  try {
    const r = await fetch("https://api.firecrawl.dev/v2/scrape", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url: parsed.toString(),
        formats: [{ type: "json", schema: SCHEMA, prompt: PROMPT }],
      }),
    });

    const text = await r.text();
    const out = safeParse(text);
    if (!r.ok || !out || out.success === false) {
      return res.status(502).json({
        error: (out && (out.error || out.message)) || "Firecrawl error (HTTP " + r.status + ")",
      });
    }

    // The extracted JSON is expected in data.json; fall back defensively.
    const data = out.data || {};
    const extracted = data.json || data.extract || null;
    if (!extracted) {
      return res.status(502).json({
        error: "Firecrawl returned no structured data",
        keys: Object.keys(data),
      });
    }
    return res.status(200).json({ url: parsed.toString(), data: extracted });
  } catch (e) {
    return res.status(500).json({ error: String(e && e.message ? e.message : e) });
  }
};

function safeParse(s) {
  try {
    return JSON.parse(s);
  } catch (e) {
    return null;
  }
}
